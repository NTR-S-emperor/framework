Open the characters.txt file and inside you will see something like this:

Girlfriend "Sarah" (gf.png) = gf
Benjamin (benjamin.png) = be
Ophélie (ophelie.png) = op
Lisa (lisa.png) = li
Stéphane (stephane.png) = st
Olivia (olivia.png) = ol
Robert (robert.png) = ro

The first line is the MC's girlfriend. Just edit her name between the quotation marks, and that will be the default name. 

Otherwise, the first word is the first name of a protagonist, then in parentheses is their profile picture (I recommend a square image, but the code automatically adapts the image if necessary), after the “=” are the abbreviations, which are useful for coding dialogues more quickly.

The character images must be placed in the “avatar” folder where characters.txt is located.