First, you need to create the characters that will appear on Messenger. Go to the “characters” folder.

Once you've done that, go to “talks” to create your conversations.