The desc.txt file allows you to define the description of your story in the display menu. There is no maximum character limit.

icon.png is the icon that your story will use in the display menu. There is no mandatory format; the icon automatically adapts, but I recommend a square format.