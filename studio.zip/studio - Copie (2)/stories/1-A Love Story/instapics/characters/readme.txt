In “characters.txt” you can list different characters that you want to appear on InstaPics. To the right of their name, in parentheses, is the avatar image they will use. Be sure to include the file extension. These images should be placed in the “avatar” folder.

There is no mandatory format for the image, but I recommend a square image.