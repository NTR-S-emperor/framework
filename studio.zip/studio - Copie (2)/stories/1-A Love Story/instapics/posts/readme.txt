SAME FUNCTION AS ONLYSLUT (except for the calling method)
Here, you can create InstaPics posts using .txt files, for example "example.txt."

From this folder, you can freely create subfolders, sub-subfolders, etc. You can organize yourself however you like, if there are different paths to your story, etc.

When you create a post and include an image in it, it is important that there is an "images" folder where your .txt file is located and which contains the image for your post.

When you call up a post in Messenger (with $insta), be sure to specify the path from the "posts" folder. For example, if you have created an example.txt file in this path: "root\stories\[YOUR STORY]\instapics\posts\lovepath", the method for calling it will be "$insta = lovepath/example.txt".

Here is an example of content (do not include the dashes):
--
Sarah
Image: example.jpg
Text: Example text. #example
Likes: 3
Comments
Elvis = That's right!
Ana 5 = Yes 😘
Alan “comments.replied” = I love you
John 18 “replied.replied” = Bastard
Anonymous “replied.replied” = ...
Elena 2 “comments.replied” = It's chat time
Lisa “comments.replied” = I'm stuck.
Anonymous “replied.replied” = Be careful.
Elon = Great!
--

"Sarah" is the name of the character posting the message. This character must have been created in the "characters" folder just before the "posts" folder.

"Image: example.jpg” is the image she includes in her message. It is not mandatory to use an image; a post does not necessarily have to be accompanied by a photo. If this is the case, simply do not include this line.

"Text: Example text." This is the text of the message. Hashtags are automatically formatted.

"Like: 3" is the number of ‘likes’ the message has received.

"Comments:" These are the comments under the message, one per line.
First the username, then =, then the text of the comment. If you want to add a number of likes to the comment, put the number of your choice to the right of the username.

The people who comment are purely fictional and do not have avatars, so there is no need to create them in the same way as those who can post messages.

The comment counter is automatic and based on the number of comments you have posted.

It is also possible to reply to comments ("comments.replied" to the right of the number of likes, or the username if there are no likes), then reply to those replies ("replied.replied" to the right of the number of likes, or the username if there are no likes).

"comments.replied" applies to the first comment detected above (so "replied.replied" is ignored).

"replied.replied" applies to the line above, so it can respond to a comment or a reply to a comment.
