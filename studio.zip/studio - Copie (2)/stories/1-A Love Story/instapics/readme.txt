To create posts, you must first ensure that you create your protagonists in the “characters” folder.

Posts are then created in the “posts” folder.