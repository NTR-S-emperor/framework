Simply name the folders freely and the story will take the name you have entered. 

The “NUMBER-” in front of the name is used to position the stories in the order you want them to appear in the menu, and is not displayed in the actual name.

For example, “2-A Love Story” will be “A Love Story” in the second position in the menu.

You can therefore freely add stories by creating a new folder and following this procedure. I recommend that you duplicate the folder from the first story, then rename it correctly to ensure that all the content is there (applications, etc.).