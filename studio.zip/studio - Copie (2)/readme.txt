System text changes (including the site title) can be changed here: system_translations.txt (note that this file also allows you to add new languages for translation).

For translations, simply duplicate a .txt file you have already created (whether in Messenger, OnlySlut, or InstaPics) and add “$EN” before the name (or the abbreviation of the language you want to apply).
For example, “start.txt” and “$FR.start.” All you have to do now is apply the translations in the file.

You can change the site's favicon by changing “favicon.png” (you must keep this name and format for the image). 

The “version.txt” file allows you to change the version number displayed at the top left of the phone to something of your choice.